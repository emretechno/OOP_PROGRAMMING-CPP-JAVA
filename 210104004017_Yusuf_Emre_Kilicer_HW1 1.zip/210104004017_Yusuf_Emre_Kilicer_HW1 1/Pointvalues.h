
#ifndef POINTVALUES_H
#define POINTVALUES_H
enum class Pointvalues : int { pawn = 1, knight = 3, bishop = 3, rook = 5, queen = 9, king =0 };

#endif